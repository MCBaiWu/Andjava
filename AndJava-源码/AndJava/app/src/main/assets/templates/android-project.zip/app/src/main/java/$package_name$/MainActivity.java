package $package_name$;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 由 AndJava IDE 自动生成的 Android 应用入口。
 *
 * 说明：
 * 1. 最低兼容 Android API 21（Android 5.0），最高目标 API 34（Android 14）
 * 2. 已配置 build.gradle 中的 namespace，R 类由 aapt 自动生成
 * 3. 修改后请点击工具栏的"运行"按钮，IDE 会自动编译并生成 APK
 */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 示例：查找布局中可能存在的 TextView/Button 并显示欢迎信息
        TextView textView = findViewById(R.id.textView);
        Button button = findViewById(R.id.button);

        if (textView != null) {
            textView.setText("Hello, AndJava IDE!");
        }
        if (button != null) {
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(MainActivity.this,
                            "按钮被点击了！", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
