@rem Minimal gradle wrapper for AndJava IDE
@echo off
gradle %*
