# ProGuard 规则 - 由 AndJava IDE 自动生成
# 默认规则通常已够用，按需在此追加

# 保留 R 类的所有字段（资源 ID 反射场景）
-keepclassmembers class **.R$* {
    public static <fields>;
}

# 保留 Activity 的 onClick 方法（XML android:onClick 反射调用）
-keepclassmembers class * extends android.app.Activity {
    public void *(android.view.View);
}

# 保留行号信息（崩溃栈有用）
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
