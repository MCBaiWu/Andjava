import java.util.Scanner;

/**
 * 由 AndJava IDE 自动生成的 Java 控制台程序。
 *
 * 修改后点击工具栏的"运行"按钮即可编译并执行。
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("============================");
        System.out.println(" Hello from AndJava IDE! ");
        System.out.println("============================");

        // 简单交互示例
        Scanner scanner = new Scanner(System.in);
        System.out.print("请输入你的名字: ");
        String name = scanner.nextLine().trim();
        if (name.isEmpty()) {
            name = "World";
        }
        System.out.println("欢迎, " + name + "!");
        scanner.close();
    }
}
