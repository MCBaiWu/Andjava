# $project_name$

这是 AndJava IDE 自动创建的 Java 控制台项目。

## 运行
- 在 IDE 中点击工具栏的"运行"按钮

## 目录
- `src/` - Java 源代码
- `libs/` - 第三方 JAR
- `bin/` - 编译输出

## 入口
- `src/Main.java`
